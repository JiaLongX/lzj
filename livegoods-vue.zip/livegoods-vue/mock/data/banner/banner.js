module.exports = {
    status:200,
    data: ['http://localhost:4006/static/banner1.png', 'http://localhost:4006/static/banner2.png', 'http://localhost:4006/static/banner3.png']
}
