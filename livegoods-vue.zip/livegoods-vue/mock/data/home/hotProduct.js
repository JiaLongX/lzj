module.exports = {
    status:200,
    data: [
        {
            id: Math.random().toString().slice(2),
            title: "北京储物柜",
            img: 'http://iwenwiki.com/api/livable/homehot/img_chuwugui.png',
            link: ""
        },
        {
            id: Math.random().toString().slice(2),
            title: "北京照明灯",
            img: "http://iwenwiki.com/api/livable/homehot/img_zhaoming.png",
            link: ""
        },
        {
            id: Math.random().toString().slice(2),
            title: "北京抱枕",
            img: "http://iwenwiki.com/api/livable/homehot/img_baozhen.png",
            link: ""
        },
        {
            id: Math.random().toString().slice(2),
            title: "北京镜子",
            img: "http://iwenwiki.com/api/livable/homehot/img_jingzi.png",
            link: ""
        }
    ]
}
