module.exports = {
    hasMore: true,
    data: [
        {
            username: '133****3355',
            comment: '房子不错，价钱好，服务也好',
            star: 5
        },
        {
            username: '137****3235',
            comment: '这房子完全没办法住了，价钱高的离谱，服务差的要命。重点是甲醛超标，必须给个差评',
            star: 1
        },
        {
            username: '185****2425',
            comment: '我对门是自如房子，他们实在是过分了。装修完毕之后楼道的垃圾也不收拾，找自如管家，竟然说是装修师傅的事情，他们管不了',
            star: 2
        },
        {
            username: '157****5549',
            comment: '我租的比较早，价钱上还算合理。是涨价之前租的。总体还是满意的。',
            star: 5
        },
        {
            username: '139****9999',
            comment: '太有钱了，任性，不做评价',
            star: 5
        }
    ]
}
