module.exports = {
   
    devServer: {
        port:80,
        proxy: {
            '/api': {
                target: 'http://192.168.10.102:4006',
                changeOrigin: true,
                pathRewrite: {
                    '^/api': ''
                }
            }
        }
    }
}
